<?php
session_start();
//$_SESSION['login']=$_SESSION['rank']='';
?>