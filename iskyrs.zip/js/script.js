function back() {
	window.onclick=document.location.href='ISregister.php';
}
function last(){
	window.onclick= alert('Закрыто на доработку');
}
function err(){
	window.onclick= alert('Для этого действия нужно войти в аккаунт или создать');
}
function vinlevel(){
	window.onclick=document.location.href='levelone.php';
}